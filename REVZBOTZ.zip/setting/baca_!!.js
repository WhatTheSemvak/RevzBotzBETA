==========[ INFO 1 ]==========

       false : untuk matiin
       true : untuk hidupin

Paham ?

==========[ INFO 2 ]==========

Kalau Error Dari Luh Jangan Chat Gw :(
Kalau Gak Tau Mending Estrak Ulang
Jika Masih Error Hapus File newbase.json


File Foto :
1. dhani.jpg : Minimal / Maximal di bawah 100 Kb 
2. thumb.jpg : Minimal / Maximal 200 Kb

Paham ?

==========[ INFO 3 ]==========

🗣️ : Bang Fiturnya Kok Error Sih ?

👤 : F , Kemungkinan ada pengantin sih
jadi tunggu aja next konten kalau ada fitur yg error !!

🗣️ : Ouh 

🗣️ : Btw ini kok pas saya run error ? 

👤 : Kalau  Gak Tau Estrak Ulang Aja Bang :)

==========[ REST API ]==========

Jika mau add fitur lain silakan
kunjungi restapi di bawah !!

https://apidhani.herokuapp.com

==========[ AKHIR ]==========

Jangan Lupa Subscribe YT : Bot Dhani ?
jan lupa dukung gua terus

Mohon Di Baca Semua Yak !!